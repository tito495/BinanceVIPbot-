# Binance Telegram Trading Bot — Professional (Full package)

Este repositório contém um bot profissional que conecta à API da Binance e é controlado via Telegram.


## O que contém
- Código modular (client, bot, strategies)
- Background strategies (DCA e Grid) com modo de simulação
- Proteções: TESTNET obrigatório por defeito, LIVE_TRADING flag
- Logging rotativo, retries e handlers de erro
- Workflow GitHub Actions para execução a partir de branch `main`
- Scripts para Termux e helpers para GitHub CLI

## IMPORTANTE (LEIA)
- **NUNCA** comite chaves no Git. Use `.env` e adicione ao `.gitignore`.
- Defina `TELEGRAM_ADMIN_ID` para o ID numérico do administrador que pode executar ordens.
- Por segurança, `LIVE_TRADING` está `false` por omissão; para trades reais coloque `LIVE_TRADING=true` **apenas** após testes.

## Como rodar (local / Termux)
1. Copie `.env.example` para `.env` e preencha as chaves (veja docs/How_to_find_TELEGRAM_ADMIN_ID.md).
2. Crie venv: `python -m venv venv` e ative-o.
3. `pip install -r requirements.txt`
4. `python telegram_bot.py`

## Deploy com GitHub Actions
1. Vá em Settings > Secrets and variables > Actions no seu repositório
2. Adicione `BINANCE_API_KEY`, `BINANCE_API_SECRET`, `TELEGRAM_TOKEN`, `TELEGRAM_ADMIN_ID`, `TESTNET`, `LIVE_TRADING`
3. Push para branch `main` — o workflow inicia o job que executa o bot (lembrete: runners GitHub não são 24/7)

## Termux
Use o script `scripts/termux_install.sh` no diretório `scripts/` para instalar e rodar no Termux.

## Segurança do token de administrador
- `TELEGRAM_ADMIN_ID` é um número (ex: 123456789). Esse valor é usado para permitir que apenas o administrador execute ordens.
- O bot **verifica** se o `update.effective_user.id` corresponde ao `TELEGRAM_ADMIN_ID`.

----
Leia os ficheiros `NOTES.md` e `docs/How_to_find_TELEGRAM_ADMIN_ID.md` antes de operar com capital real.
