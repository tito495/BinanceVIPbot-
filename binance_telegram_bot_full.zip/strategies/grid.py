"""Grid worker (simplified).
Creates a symmetric grid of limit BUY orders below current price and SELL orders above.
In simulation mode (live=False) orders are only logged.
"""
import logging
import time
from decimal import Decimal

log = logging.getLogger('bot.grid')

def grid_worker(binance_client, symbol: str, steps: int, step_percent: Decimal, lot_per_step: Decimal, stop_event, live: bool):
    symbol = symbol.replace('/', '').upper()
    log.info('Grid started: %s steps=%s step%%=%s lot=%s live=%s', symbol, steps, step_percent, lot_per_step, live)
    try:
        base_price = binance_client.get_price(symbol)
    except Exception as e:
        log.exception('Erro ao obter preço para grid: %s', e)
        return
    orders = []
    for i in range(1, steps+1):
        if stop_event.is_set():
            break
        buy_price = base_price * (Decimal('1') - (step_percent/Decimal('100') * i))
        sell_price = base_price * (Decimal('1') + (step_percent/Decimal('100') * i))
        if live:
            # Place limit buy and sell orders (dangerous!)
            try:
                buy_order = binance_client.create_limit_order(symbol, 'BUY', lot_per_step, buy_price)
                sell_order = binance_client.create_limit_order(symbol, 'SELL', lot_per_step, sell_price)
                orders.append((buy_order, sell_order))
                log.info('Placed grid step %s: BUY@%s SELL@%s', i, buy_price, sell_price)
            except Exception as e:
                log.exception('Erro ao colocar ordens de grid: %s', e)
        else:
            orders.append({'buy': str(buy_price), 'sell': str(sell_price), 'lot': str(lot_per_step)})
            log.info('Simulated grid step %s: BUY@%s SELL@%s', i, buy_price, sell_price)
        time.sleep(1)
    log.info('Grid finished for %s: steps=%s', symbol, len(orders))
    return orders
