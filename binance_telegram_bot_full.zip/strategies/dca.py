"""DCA worker.
This worker is intended to be run inside a thread using asyncio.to_thread.
It will perform `num_buys` market buys spaced by `interval_minutes`.
If `live` is False the worker only simulates orders (logs them) and does not send them to Binance.
A `stop_event` threading.Event can be set to request cancellation.
"""
import time
import logging
from decimal import Decimal

log = logging.getLogger('bot.dca')

def dca_worker(binance_client, symbol: str, total_invest: Decimal, num_buys: int, interval_minutes: int, stop_event, live: bool):
    symbol = symbol.replace('/', '').upper()
    log.info('DCA started: %s total=%s num=%s every=%smin live=%s', symbol, total_invest, num_buys, interval_minutes, live)
    per_buy = (total_invest / Decimal(num_buys)) if num_buys > 0 else Decimal('0')
    bought = []
    for i in range(num_buys):
        if stop_event.is_set():
            log.info('DCA stopped by user after %s buys', i)
            break
        try:
            price = binance_client.get_price(symbol)
            qty = (per_buy / price).quantize(Decimal('0.00000001'))
            if live:
                order = binance_client.create_market_order(symbol, 'BUY', qty)
                log.info('DCA buy placed: %s', order)
            else:
                order = {'simulated': True, 'symbol': symbol, 'qty': str(qty), 'price': str(price)}
                log.info('DCA simulated buy: %s', order)
            bought.append(order)
        except Exception as e:
            log.exception('Erro durante DCA buy: %s', e)
        # wait interval
        for _ in range(interval_minutes * 6):  # check stop every 10s
            if stop_event.is_set():
                break
            time.sleep(10)
    log.info('DCA finished for %s. Bought %s entries', symbol, len(bought))
    return bought
