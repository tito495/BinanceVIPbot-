#!/data/data/com.termux/files/usr/bin/bash
# Termux install script (may require adjustments for your device)
set -e
echo "Updating packages..."
pkg update -y
pkg install -y python git
python -m pip install --upgrade pip
python -m venv venv
. venv/bin/activate
pip install -r requirements.txt
echo "Copy .env.example to .env and edit it with your keys. Then run:"
echo "python telegram_bot.py"
