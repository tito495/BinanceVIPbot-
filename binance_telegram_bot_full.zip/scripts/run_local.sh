#!/usr/bin/env bash
# Quick runner for local development
. venv/bin/activate || source venv/bin/activate
python telegram_bot.py
