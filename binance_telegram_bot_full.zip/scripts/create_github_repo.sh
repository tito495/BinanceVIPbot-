#!/usr/bin/env bash
# Helper script to create GitHub repo using gh CLI and push local repo
# Requires: gh (GitHub CLI) installed and authenticated
if ! command -v gh >/dev/null 2>&1; then
  echo "Install GitHub CLI (gh) first: https://cli.github.com/"
  exit 1
fi
REPO_NAME=${1:-binance-telegram-bot}
gh repo create "$REPO_NAME" --public --source=. --push
echo "Repo created and pushed. Remember to add secrets via Settings > Secrets and variables > Actions"
