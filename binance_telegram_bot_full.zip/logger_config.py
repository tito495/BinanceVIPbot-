import logging
from logging.handlers import RotatingFileHandler
import os

LOG_FILE = os.getenv('LOG_FILE', 'bot.log')
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').upper()

logger = logging.getLogger('bot')
logger.setLevel(LOG_LEVEL)

formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(name)s | %(message)s')

# Console handler
ch = logging.StreamHandler()
ch.setFormatter(formatter)
logger.addHandler(ch)

# Rotating file handler
fh = RotatingFileHandler(LOG_FILE, maxBytes=5_000_000, backupCount=5)
fh.setFormatter(formatter)
logger.addHandler(fh)
