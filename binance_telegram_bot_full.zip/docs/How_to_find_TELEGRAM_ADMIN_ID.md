## How to find your TELEGRAM_ADMIN_ID (numeric)

1. Open Telegram and search for the bot `@userinfobot` or `@get_id_bot`.
2. Start the bot and press /start — it will show your numeric user id.
3. Alternatively, send any message to your bot and check the logs; `update.effective_user.id` will be present.

Use that numeric id and set it in `.env` as TELEGRAM_ADMIN_ID=123456789
