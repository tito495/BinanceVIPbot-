"""
Synchronous wrapper around python-binance with retries and simple helpers.
"""
import logging
from binance.client import Client
from binance.exceptions import BinanceAPIException
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from decimal import Decimal, ROUND_DOWN
from config import BINANCE_API_KEY, BINANCE_API_SECRET, TESTNET, MAX_ORDER_RETRIES

logger = logging.getLogger('bot.binance')

class BinanceClient:
    def __init__(self):
        if not BINANCE_API_KEY or not BINANCE_API_SECRET:
            raise RuntimeError('Binance API keys não definidas')
        # Connect client
        self.client = Client(BINANCE_API_KEY, BINANCE_API_SECRET, testnet=TESTNET)
        if TESTNET:
            # testnet base
            self.client.API_URL = 'https://testnet.binance.vision/api'
        logger.info('Binance client inicializado (testnet=%s)', TESTNET)

    @retry(stop=stop_after_attempt(MAX_ORDER_RETRIES), wait=wait_exponential(multiplier=1, min=1, max=10),
           retry=retry_if_exception_type(Exception))
    def get_price(self, symbol: str) -> Decimal:
        symbol = symbol.replace('/', '').upper()
        ticker = self.client.get_symbol_ticker(symbol=symbol)
        return Decimal(ticker['price'])

    @retry(stop=stop_after_attempt(MAX_ORDER_RETRIES), wait=wait_exponential(multiplier=1, min=1, max=10),
           retry=retry_if_exception_type(Exception))
    def get_account_balances(self):
        account = self.client.get_account()
        balances = {b['asset']: Decimal(b['free']) for b in account['balances'] if Decimal(b['free']) > 0}
        return balances

    def _format_quantity(self, symbol: str, qty: Decimal) -> str:
        info = self.client.get_symbol_info(symbol.replace('/', '').upper())
        if not info:
            raise ValueError('Símbolo inválido')
        filters = info.get('filters', [])
        step = Decimal('1')
        for f in filters:
            if f.get('filterType') == 'LOT_SIZE':
                step = Decimal(f['stepSize'])
                break
        quantized = qty.quantize(step, rounding=ROUND_DOWN)
        return format(quantized, 'f')

    @retry(stop=stop_after_attempt(MAX_ORDER_RETRIES), wait=wait_exponential(multiplier=1, min=1, max=10),
           retry=retry_if_exception_type(Exception))
    def create_market_order(self, symbol: str, side: str, quantity: Decimal):
        symbol = symbol.replace('/', '').upper()
        side = side.upper()
        qty_formatted = self._format_quantity(symbol, quantity)
        logger.info('Enviando ordem MARKET %s %s %s', side, symbol, qty_formatted)
        order = self.client.create_order(symbol=symbol, side=side, type='MARKET', quantity=qty_formatted)
        return order

    @retry(stop=stop_after_attempt(MAX_ORDER_RETRIES), wait=wait_exponential(multiplier=1, min=1, max=10),
           retry=retry_if_exception_type(Exception))
    def create_limit_order(self, symbol: str, side: str, quantity: Decimal, price: Decimal):
        symbol = symbol.replace('/', '').upper()
        side = side.upper()
        qty_formatted = self._format_quantity(symbol, quantity)
        price_str = format(price, 'f')
        logger.info('Enviando ordem LIMIT %s %s %s @ %s', side, symbol, qty_formatted, price_str)
        order = self.client.create_order(symbol=symbol, side=side, type='LIMIT', timeInForce='GTC', quantity=qty_formatted, price=price_str)
        return order
