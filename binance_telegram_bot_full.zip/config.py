from dotenv import load_dotenv
import os

load_dotenv()

BINANCE_API_KEY = os.getenv('BINANCE_API_KEY')
BINANCE_API_SECRET = os.getenv('BINANCE_API_SECRET')
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
TELEGRAM_ADMIN_ID = int(os.getenv('TELEGRAM_ADMIN_ID', '0'))
TESTNET = os.getenv('TESTNET', 'true').lower() in ('1', 'true', 'yes')
LIVE_TRADING = os.getenv('LIVE_TRADING', 'false').lower() in ('1', 'true', 'yes')
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
MAX_ORDER_RETRIES = int(os.getenv('MAX_ORDER_RETRIES', '3'))

if not TELEGRAM_TOKEN:
    raise RuntimeError('TELEGRAM_TOKEN não definido no .env')
