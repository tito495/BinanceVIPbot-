Recomendações antes de usar com capital real:
1. Testar exaustivamente no Testnet (definir TESTNET=true e usar chaves do testnet).
2. Revisar limites de lotes e precisão para cada símbolo; o bot tenta respeitar LOT_SIZE.
3. Implementar monitor de ordens abertas e reconciliar execuções (não feito aqui automaticamente).
4. Considere adicionar autenticação adicional no Telegram para usuários administrativos.
5. Faça pequenos testes com valores baixos antes de aumentar capital.
