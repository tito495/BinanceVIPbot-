from decimal import Decimal, InvalidOperation
import logging

logger = logging.getLogger('bot.utils')

def parse_decimal(value: str) -> Decimal:
    try:
        return Decimal(value)
    except (InvalidOperation, ValueError) as e:
        logger.exception('Erro ao converter para Decimal: %s', value)
        raise ValueError('Quantidade inválida')
