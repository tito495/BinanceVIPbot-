"""
Async Telegram bot using python-telegram-bot v20.
Includes commands to manage background strategies (DCA / Grid) and status.
"""
import asyncio
import logging
import traceback
import threading
import time
from telegram.ext import Application, CommandHandler, ContextTypes
from telegram import Update
from telegram.constants import ParseMode
from config import TELEGRAM_TOKEN, TELEGRAM_ADMIN_ID, TESTNET, LIVE_TRADING
from binance_client import BinanceClient
from logger_config import logger
from utils import parse_decimal
from decimal import Decimal
import strategies.dca as dca_module
import strategies.grid as grid_module

binance = BinanceClient()
log = logging.getLogger('bot')

# running strategies store
running_strategies = {}

def admin_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        if user_id != TELEGRAM_ADMIN_ID:
            await update.message.reply_text('Acesso negado. Apenas o administrador pode executar este comando.')
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = (
        '🤖 *Bot de Trading*\n\n'
        'Comandos:\n'
        '/start - iniciar\n'
        '/price <SYMBOL> - obter preço atual (ex: BTCUSDT)\n'
        '/buy <SYMBOL> <QTY> - comprar mercado\n'
        '/sell <SYMBOL> <QTY> - vender mercado\n'
        '/order <SIDE> <SYMBOL> <QTY> [LIMIT_PRICE] - criar ordem (LIMIT se passar preço)\n'
        '/balance - ver saldos\n'
        '/start_dca <SYMBOL> <TOTAL_INVEST> <NUM_BUYS> <INTERVAL_MINUTES> - iniciar DCA\n'
        '/stop_dca <SYMBOL> - parar DCA\n'
        '/start_grid <SYMBOL> <GRID_STEPS> <STEP_PERCENT> <LOT_PER_STEP> - iniciar Grid\n'
        '/stop_grid <SYMBOL> - parar Grid\n'
        '/status - mostrar status do bot\n'
        '/help - ajuda\n'
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)

async def price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text('Uso: /price <SYMBOL>')
        return
    symbol = context.args[0]
    try:
        price = await asyncio.to_thread(binance.get_price, symbol)
        await update.message.reply_text(f'Preço {symbol.upper()}: {price}')
    except Exception as e:
        log.exception('Erro no /price')
        await update.message.reply_text(f'Erro ao obter preço: {e}')

@admin_only
async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        bals = await asyncio.to_thread(binance.get_account_balances)
        if not bals:
            await update.message.reply_text('Sem saldos disponíveis.')
            return
        msg = '\n'.join([f"{k}: {v}" for k, v in bals.items()])
        await update.message.reply_text(f'Saldos:\n{msg}')
    except Exception as e:
        log.exception('Erro no /balance')
        await update.message.reply_text(f'Erro ao obter saldos: {e}')

@admin_only
async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text('Uso: /buy <SYMBOL> <QTY>')
        return
    symbol = context.args[0]
    try:
        qty = parse_decimal(context.args[1])
    except Exception as e:
        await update.message.reply_text(str(e))
        return
    try:
        order = await asyncio.to_thread(binance.create_market_order, symbol, 'BUY', qty)
        await update.message.reply_text(f'Ordem executada:\n{order}')
    except Exception as e:
        log.exception('Erro no /buy')
        await update.message.reply_text(f'Erro ao executar ordem: {e}')

@admin_only
async def sell(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text('Uso: /sell <SYMBOL> <QTY>')
        return
    symbol = context.args[0]
    try:
        qty = parse_decimal(context.args[1])
    except Exception as e:
        await update.message.reply_text(str(e))
        return
    try:
        order = await asyncio.to_thread(binance.create_market_order, symbol, 'SELL', qty)
        await update.message.reply_text(f'Ordem executada:\n{order}')
    except Exception as e:
        log.exception('Erro no /sell')
        await update.message.reply_text(f'Erro ao executar ordem: {e}')

@admin_only
async def order_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # /order SIDE SYMBOL QTY [LIMIT_PRICE]
    if len(context.args) < 3:
        await update.message.reply_text('Uso: /order <SIDE> <SYMBOL> <QTY> [LIMIT_PRICE]')
        return
    side = context.args[0].upper()
    symbol = context.args[1]
    try:
        qty = parse_decimal(context.args[2])
    except Exception as e:
        await update.message.reply_text(str(e))
        return
    price = None
    if len(context.args) >= 4:
        try:
            price = parse_decimal(context.args[3])
        except Exception as e:
            await update.message.reply_text('Preço inválido')
            return
    try:
        if price:
            order = await asyncio.to_thread(binance.create_limit_order, symbol, side, qty, price)
        else:
            order = await asyncio.to_thread(binance.create_market_order, symbol, side, qty)
        await update.message.reply_text(f'Ordem resultante:\n{order}')
    except Exception as e:
        log.exception('Erro no /order')
        await update.message.reply_text(f'Erro ao criar ordem: {e}')

@admin_only
async def start_dca(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # /start_dca SYMBOL TOTAL_INVEST NUM_BUYS INTERVAL_MINUTES
    if len(context.args) < 4:
        await update.message.reply_text('Uso: /start_dca <SYMBOL> <TOTAL_INVEST> <NUM_BUYS> <INTERVAL_MINUTES>')
        return
    symbol = context.args[0]
    try:
        total = Decimal(context.args[1])
        num = int(context.args[2])
        interval = int(context.args[3])
    except Exception:
        await update.message.reply_text('Parâmetros inválidos')
        return
    key = f'dca_{symbol.upper()}'
    if key in running_strategies:
        await update.message.reply_text('Já existe um DCA a correr para esse símbolo.')
        return
    if not TESTNET and not LIVE_TRADING:
        await update.message.reply_text('Para operar ao vivo defina LIVE_TRADING=true no .env. Atualmente apenas Testnet é permitido.')
        return
    stop_event = threading.Event()
    task = asyncio.create_task(asyncio.to_thread(dca_module.dca_worker, binance, symbol, total, num, interval, stop_event, TESTNET or LIVE_TRADING))
    running_strategies[key] = {'task': task, 'stop': stop_event, 'meta': {'symbol': symbol, 'type': 'DCA'}}
    await update.message.reply_text(f'DCA iniciado para {symbol}. Use /stop_dca {symbol} para parar.')

@admin_only
async def stop_dca(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text('Uso: /stop_dca <SYMBOL>')
        return
    symbol = context.args[0]
    key = f'dca_{symbol.upper()}'
    info = running_strategies.get(key)
    if not info:
        await update.message.reply_text('Nenhum DCA encontrado para esse símbolo.')
        return
    info['stop'].set()
    await update.message.reply_text(f'Solicitado stop do DCA para {symbol}.')

@admin_only
async def start_grid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # /start_grid SYMBOL GRID_STEPS STEP_PERCENT LOT_PER_STEP
    if len(context.args) < 4:
        await update.message.reply_text('Uso: /start_grid <SYMBOL> <GRID_STEPS> <STEP_PERCENT> <LOT_PER_STEP>')
        return
    symbol = context.args[0]
    try:
        steps = int(context.args[1])
        step_pct = Decimal(context.args[2])
        lot = Decimal(context.args[3])
    except Exception:
        await update.message.reply_text('Parâmetros inválidos')
        return
    key = f'grid_{symbol.upper()}'
    if key in running_strategies:
        await update.message.reply_text('Já existe um Grid a correr para esse símbolo.')
        return
    if not TESTNET and not LIVE_TRADING:
        await update.message.reply_text('Para operar ao vivo defina LIVE_TRADING=true no .env. Atualmente apenas Testnet é permitido.')
        return
    stop_event = threading.Event()
    task = asyncio.create_task(asyncio.to_thread(grid_module.grid_worker, binance, symbol, steps, step_pct, lot, stop_event, TESTNET or LIVE_TRADING))
    running_strategies[key] = {'task': task, 'stop': stop_event, 'meta': {'symbol': symbol, 'type': 'GRID'}}
    await update.message.reply_text(f'Grid iniciado para {symbol}. Use /stop_grid {symbol} para parar.')

@admin_only
async def stop_grid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text('Uso: /stop_grid <SYMBOL>')
        return
    symbol = context.args[0]
    key = f'grid_{symbol.upper()}'
    info = running_strategies.get(key)
    if not info:
        await update.message.reply_text('Nenhum Grid encontrado para esse símbolo.')
        return
    info['stop'].set()
    await update.message.reply_text(f'Solicitado stop do Grid para {symbol}.')

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    parts = []
    parts.append(f'TESTNET={TESTNET} LIVE_TRADING={LIVE_TRADING}')
    parts.append('Running strategies:')
    if not running_strategies:
        parts.append('  Nenhuma')
    else:
        for k, v in running_strategies.items():
            parts.append(f"  {k}: {v['meta']}")
    # show balance summary
    try:
        bals = await asyncio.to_thread(binance.get_account_balances)
        top = ', '.join([f"{k}:{v}" for k,v in list(bals.items())[:5]])
        parts.append('Balances: ' + (top or 'Sem saldos'))
    except Exception:
        parts.append('Balances: erro ao obter')
    await update.message.reply_text('\n'.join(parts))

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.error('Exception while handling an update:', exc_info=context.error)
    try:
        if update and hasattr(update, 'effective_message') and update.effective_message:
            await update.effective_message.reply_text('Ocorreu um erro no bot. Verifique os logs.')
    except Exception:
        log.exception('Erro ao reportar erro ao usuário')

async def main():
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    application.add_handler(CommandHandler('start', start))
    application.add_handler(CommandHandler('help', help_cmd))
    application.add_handler(CommandHandler('price', price))
    application.add_handler(CommandHandler('buy', buy))
    application.add_handler(CommandHandler('sell', sell))
    application.add_handler(CommandHandler('balance', balance))
    application.add_handler(CommandHandler('order', order_cmd))
    application.add_handler(CommandHandler('start_dca', start_dca))
    application.add_handler(CommandHandler('stop_dca', stop_dca))
    application.add_handler(CommandHandler('start_grid', start_grid))
    application.add_handler(CommandHandler('stop_grid', stop_grid))
    application.add_handler(CommandHandler('status', status))
    application.add_error_handler(error_handler)

    log.info('Bot iniciado. Aguardando comandos...')
    await application.run_polling()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
